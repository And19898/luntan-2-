package com.ivi.android.autopackage.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;

import com.ivi.android.autopackage.R;
import com.ivi.android.autopackage.databinding.ActivityWebviewBinding;
import com.ivi.android.autopackage.utils.Cons;
import com.ivi.android.autopackage.utils.ToastUtils;
import com.ivi.android.autopackage.webview.x5.clients.IWebViewClient;
import com.ivi.android.autopackage.webview.x5.tools.WebTools;
import com.tencent.smtt.export.external.interfaces.WebResourceRequest;
import com.tencent.smtt.export.external.interfaces.WebResourceResponse;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.utils.LogFileUtils;

import java.util.Arrays;
import java.util.List;

import static com.ivi.android.autopackage.utils.Cons.AUTO_URL;


public class WebViewActivity extends UIActivity<ActivityWebviewBinding> implements View.OnClickListener {

    String query = "\"img[longdesc='http://byl98.com']\"";

    String js = "var img1 = document.querySelector("+query+");img1 && img1.parentNode && img1.parentNode.parentNode && img1.parentNode.parentNode.remove();";
    @Override
    protected void init() {
        toolbar.setVisibility(View.GONE);

        databinding.progressWebview.getWebView().loadUrl(AUTO_URL);
        Log.e("js-----------", js);
        databinding.progressWebview.setIWebViewClient(new IWebViewClient(databinding.progressWebview){
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(js, null);
            }
        });
    }

    private WebResourceResponse getWebResourceResponse(String url) {
        List<String> urls = Arrays.asList(Cons.INT_URL);
        if (urls.contains(url)) {
            return new WebResourceResponse(null, null, null);
        }
        return null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        WebTools.releaseWebView(databinding.progressWebview.getWebView());
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_webview;
    }


    @Override
    public void onClick(View v) {
        if (databinding.progressWebview.getWebView().canGoBack()) {
            databinding.progressWebview.getWebView().goBack();
        }
    }


    private long backTime;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (backTime == 0) {
                backTime = System.currentTimeMillis();
                ToastUtils.toastWarn(this, getString(R.string.hybrid_exit_app));
                return true;
            }
            if ((System.currentTimeMillis() - backTime) >= 2000) {
                backTime = System.currentTimeMillis();
                ToastUtils.toastWarn(this, getString(R.string.hybrid_exit_app));
                return true;
            }
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
